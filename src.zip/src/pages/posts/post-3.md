---
layout: ../../layouts/MarkdownPostLayout.astro
title: Mi tercera publicación en el blog
author: Alumno de Astro
description: "Tuve algunos problemas, pero preguntar en la comunidad me ayudó mucho."
image:
    url: "https://docs.astro.build/assets/rays.webp"
    alt: "Miniatura de los rayos de Astro."
pubDate: 2022-07-15
tags: ["astro", "aprender en público", "contratiempos", "comunidad"]
---
No siempre ha sido fácil, pero disfruto construyendo con Astro. Además, la [comunidad de Discord](https://astro.build/chat) es muy amable y servicial.